package com.bytedance.android.lesson.restapi.solution.bean;

import com.google.gson.annotations.SerializedName;

import retrofit2.Call;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.GET;

/**
 * @author Xavier.S
 * @date 2019.01.17 18:08
 */
public class Cat {

    // TODO-C1 (1)Implement your Cat Bean here according to the response json

    @SerializedName("id") private String id;
    @SerializedName("url") private String url;
    @SerializedName("width") private int width;
    @SerializedName("height") private int height;
    public String getId(){
        return id;
    }

    public String getUrl(){
        return url;
    }

    public int getWidth(){
        return width;
    }
    public int getHeight(){
        return height;
    }

    @Override public String toString() {
        return "Cat{" +
                "id='" + id + '\'' +
                ", url=" + url + '\'' +
                ", width=" + width +
                ", height=" + height +
                '}';
    }

}
